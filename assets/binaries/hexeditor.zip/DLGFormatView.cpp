// DLGFormatView.cpp : implementation file
//

#include "stdafx.h"
#include "HexEditor.h"
#include "DLGFormatView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDLGFormatView dialog


CDLGFormatView::CDLGFormatView(CWnd* pParent /*=NULL*/)
	: CDialog(CDLGFormatView::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDLGFormatView)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CDLGFormatView::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDLGFormatView)
	DDX_Control(pDX, IDC_FVIEW, m_wndFView);
	//}}AFX_DATA_MAP
}

void CDLGFormatView::Load( char* pszBuffer, CString szFormatPath )
{
	// open the file
	FILE* fh = fopen( szFormatPath.GetBuffer(0), "r" );
	if( !fh )
	{
		MessageBox( "Script Not Found" );
		return;
	}

	// start parsing the script
	m_feElements.clear();
	char* pszScript;
	CString szScript;
	CString szCommand, szName, szCount;
	int nIndex, nLen;
	while( !feof( fh ) )
	{
		// read the line
		pszScript = szScript.GetBuffer( 256 );
		if( !fgets( pszScript, 256, fh ) )
			break;
		szScript.ReleaseBuffer();
		
		// get the data
		// type
		nLen = szScript.Find( "(", 0 );
		if( nLen == -1 ) continue;
		szCommand = szScript.Left( nLen );
		// name
		nIndex = nLen+1;
		nLen = szScript.Find( ")", nLen );
		if( nLen == -1 ) continue;
		szName = szScript.Mid( nIndex, nLen - nIndex );
		// count
		nIndex = nLen+2;
		nLen = szScript.Find( "]", nLen );
		if( nLen == -1 ) continue;
		szCount = szScript.Mid( nIndex, nLen - nIndex );

		// add by type
		if( CAction::IsAction( szName ) )
			AddAction( szCommand, szName, szCount );
		else
			AddVariable( szName, szCount, szCommand );
	}
	fclose( fh );

	// now piece together remaining data
	int nDataIndex = 0;
	unsigned int i;
	CFormatElement* pFE;
	CVariable* pVar;
	CAction* pAction;
	for( i = 0; i < m_feElements.size(); i++ )
	{
		// get a pointer to the element
		pFE = &m_feElements[i];
		// set count
		pFE->m_nCount = GetValue( pFE->m_szCount );
		// set data index
		pFE->m_nDataPos = nDataIndex;
		// act by type
		if( pFE->IsVariable() )
		{
			// get pointer
			pVar = (CVariable *)pFE;
			// increment data index
			nDataIndex += pVar->GetSize();
		} else
		{
			// get pointer
			pAction = (CAction *)pFE;
			// set element index
			pAction->m_nElementIndex = i;
		}
	}			
}

void CDLGFormatView::AddAction( CString szCommand, CString szName, CString szCount )
{
	CAction* pAction = new CAction( szCommand, szName, szCount );
	m_feElements.push_back( *pAction );
}

void CDLGFormatView::AddVariable( CString szName, CString szCount, CString szType )
{
	CVariable* pVariable = new CVariable( szName, szType, szCount );
	m_feElements.push_back( *pVariable );
}

BEGIN_MESSAGE_MAP(CDLGFormatView, CDialog)
	//{{AFX_MSG_MAP(CDLGFormatView)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDLGFormatView message handlers

BOOL CDLGFormatView::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// create view control
	m_wndFView.InsertColumn( "

	// TODO - PROMPT FOR SCRIPT
	Load( NULL, "mdt.txt" );

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
