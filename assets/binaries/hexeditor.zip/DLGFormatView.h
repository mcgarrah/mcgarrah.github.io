#if !defined(AFX_DLGFORMATVIEW_H__59DAA662_B838_11D7_9734_00045A4C0065__INCLUDED_)
#define AFX_DLGFORMATVIEW_H__59DAA662_B838_11D7_9734_00045A4C0065__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DLGFormatView.h : header file
//

#include <vector>
using namespace::std;

/////////////////////////////////////////////////////////////////////////////
// Script data structures
class CFormatElement
{
// Constructor
public:
	CFormatElement() {};
	CFormatElement( CString szName, CString szCount )
	{
		m_szName = szName;
		m_szCount = szCount;
		m_nCount = 0;
		m_fVariable = FALSE;
		m_nDataPos = 0;
	}

// Operations
	void operator = (CFormatElement fe)
	{
		m_szName = fe.m_szName;
		m_szCount = fe.m_szCount;
		m_nCount = fe.m_nCount;
	}
	BOOL IsVariable() { return m_fVariable; };

// Variables
	CString m_szName;
	CString m_szCount;
	int m_nCount;
	BOOL m_fVariable;
	int m_nDataPos;
};

class CAction : public CFormatElement
{
// Constructor
public:
	CAction() {};
	CAction( CString szCommand, CString szParameters, CString szCount ) : CFormatElement( szCommand, szCount )
	{
		m_szParameters = szParameters;
		m_nElementIndex = 0;
	}
	~CAction() {};

// Operations
	static BOOL IsAction( CString szString )
	{
		if( szString == "if" || szString == "elseif" || szString == "else" ||
			szString == "endif" || szString == "repeat" || szString == "endrepeat" )
			return TRUE;
		return FALSE;
	}
	void operator = (CAction a)
	{
		m_szName = a.m_szName;
		m_szCount = a.m_szCount;
		m_nCount = a.m_nCount;
		m_szParameters = a.m_szParameters;
	}

// Variables
	CString m_szParameters;
	int m_nElementIndex;
};

class CVariable : public CFormatElement
{
// Constructor
public:
	CVariable() {};
	CVariable( CString szName, CString szVarType, CString szCount ) : CFormatElement( szName, szCount )
	{
		if( szVarType == "char" ) m_eVarType = VAR_CHAR;
		else if( szVarType == "byte" ) m_eVarType = VAR_BYTE;
		else if( szVarType == "short" ) m_eVarType = VAR_SHORT;
		else if( szVarType == "long" ) m_eVarType = VAR_LONG;
		else m_eVarType = VAR_FLOAT;
		m_fVariable = TRUE;
	}
	~CVariable() {};

// Operations
	void operator = (CVariable v)
	{
		m_szName = v.m_szName;
		m_szCount = v.m_szCount;
		m_nCount = v.m_nCount;
		m_eVarType = v.m_eVarType;
		m_nDataPos = v.m_nDataPos;
	}
	int GetSize()
	{
		int nSize = 0;
		if( m_eVarType == VAR_CHAR || m_eVarType == VAR_BYTE )
			nSize = 1;
		else if( m_eVarType == VAR_SHORT )
			nSize = sizeof( short );
		else if( m_eVarType == VAR_LONG )
			nSize = sizeof( long );
		else if( m_eVarType == VAR_FLOAT )
			nSize = sizeof( float );
		nSize *= nCount;
	}

// Variables
	enum vartype_e
	{
		VAR_CHAR=0,
		VAR_BYTE,
		VAR_SHORT,
		VAR_LONG,
		VAR_FLOAT,
	} m_eVarType;
};

/////////////////////////////////////////////////////////////////////////////
// CDLGFormatView dialog

class CDLGFormatView : public CDialog
{
// Construction
public:
	CDLGFormatView(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDLGFormatView)
	enum { IDD = IDD_FORMATVIEW };
	CListCtrl	m_wndFView;
	//}}AFX_DATA

// Operations
	void Load( char* pszBuffer, CString szFormatPath );
	void AddAction( CString szCommand, CString szName, CString szCount );
	void AddVariable( CString szName, CString szCount, CString szType );
	
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDLGFormatView)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	vector<CFormatElement> m_feElements;

	// Generated message map functions
	//{{AFX_MSG(CDLGFormatView)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGFORMATVIEW_H__59DAA662_B838_11D7_9734_00045A4C0065__INCLUDED_)
