//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by HexEditor.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_FILETYPE                    129
#define IDD_INSERTDATA                  130
#define IDR_CONTEXT                     131
#define IDD_EDITDATA                    132
#define IDD_PROGRESS                    133
#define IDD_FORMATVIEW                  134
#define IDC_INSERTAMT                   1000
#define IDC_DATA                        1001
#define IDC_INPUT                       1002
#define IDC_PROGRESSBAR                 1003
#define IDC_TASK                        1004
#define IDC_MINIPROGRESSBAR             1005
#define IDC_ABORT                       1006
#define IDC_FVIEW                       1007
#define ID_EDIT_INSERT                  32771
#define ID_CONTEXT_INSERTBYTES          32772
#define ID_CONTEXT_EDITSTRING           32774
#define ID_CONTEXT_EDITINTEGER          32775
#define ID_CONTEXT_EDITHEX              32776
#define ID_VIEW_FORMAT                  32777

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32778
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
